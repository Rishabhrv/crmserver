// src/pages/HomePage.jsx
import React, { useState, useEffect } from "react";
import Slidebar from "../components/Slidebar";
import HomePageUsers from "../components/HomePageUsers";
import HomePageMsg from "../components/HomePageMsg";

const HomePage = () => {
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [user, setUser] = useState(null);
  const [selectedConv, setSelectedConv] = useState(null);

  useEffect(() => {
    // 1️⃣ Read token from URL
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get("token");

    const activeToken = urlToken || localStorage.getItem("token");

    if (urlToken) {
      localStorage.setItem("token", urlToken);
      setToken(urlToken);
      // remove token from URL for clean look
      // window.history.replaceState({}, document.title, "/chatapp");
    } else if (activeToken) {
      setToken(activeToken);
    }

    // 2️⃣ Fetch user details from backend
    if (activeToken) {
      fetch("http://localhost:5001/auth/validate_and_details", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: activeToken }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.valid) {
            setUser({
              id: data.user_id,
              ...data.user_details,
            });
          } else {
            console.warn("Token invalid:", data.error);
            setUser(null);
            localStorage.removeItem("token");
          }
        })
        .catch((err) => {
          console.error("Failed to fetch user details:", err);
          setUser(null);
          localStorage.removeItem("token");
        });
    }
  }, []);

  if (!token || !user) {
    return (
      <div className="flex items-center justify-center h-screen">
        <h2 className="text-gray-600 text-xl font-semibold">
          Loading user info...
        </h2>
      </div>
    );
  }

  return (
    <div className="flex">
      <Slidebar user={user} />
      <HomePageUsers
        token={token}
        onSelectConversation={(conv) => setSelectedConv(conv)}
        user={user}
      />
      <HomePageMsg token={token} conversation={selectedConv} user={user} />
    </div>
  );
};

export default HomePage;
