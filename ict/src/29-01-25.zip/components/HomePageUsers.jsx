// src/components/HomePageUsers.jsx
import React, { useEffect, useState } from "react";

const HomePageUsers = ({ token, onSelectConversation, user }) => {
  const [convos, setConvos] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  

  // Fetch conversations
  useEffect(() => {
  fetch("http://localhost:5001/conversations", {
    headers: { Authorization: `Bearer ${token}` },
  })
    .then((r) => r.json())
    .then((data) => {
      if (Array.isArray(data)) setConvos(data);
      else setConvos([]); // fallback if backend returns error object
    })
    .catch((err) => {
      console.error(err);
      setConvos([]);
    });
}, [token]);

  // Handle search
  useEffect(() => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }

    setLoading(true);
    const timer = setTimeout(() => {
      fetch(`http://localhost:5001/users?search=${encodeURIComponent(searchTerm)}`, {
  headers: { Authorization: `Bearer ${token}` },
})
  .then((r) => r.json())
  .then((data) => {
    const userList = Array.isArray(data) ? data : [];
    const existingMatches = convos.filter((c) =>
      c.other_username?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    const existingUsernames = new Set(convos.map((c) => c.other_username));
    const newUsers = userList.filter((u) => !existingUsernames.has(u.username));
    setSearchResults([...existingMatches, ...newUsers]);
  })
  .catch((err) => console.error(err))
  .finally(() => setLoading(false));

    }, 400); // debounce input

    return () => clearTimeout(timer);
  }, [searchTerm, convos, token]);

  const listToShow = searchTerm ? searchResults : convos;

  return (
    <div className="ml-4 w-72">
      {/* 🔍 Search Bar */}
      <div className="flex items-center bg-white rounded-2xl shadow-sm px-3 py-2 w-74 mt-4">
        <input
          type="text"
          className="w-full outline-none text-gray-700 placeholder-gray-400"
          placeholder="Search user or conversation"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* 🧭 Filters */}
      <div className="my-3 flex justify-between border-b border-gray-300 pb-2">
        <div>
          <button className="bg-gray-50 text-xs shadow-sm px-2 rounded-lg font-semibold text-gray-500">
            New
          </button>
          <button className="bg-gray-50 text-xs shadow-sm px-2 rounded-lg font-semibold text-gray-500 ml-2">
            UnRead
          </button>
        </div>
      </div>

      {/* 💬 Conversation/User List */}
      <div>
        {loading && <div className="p-4 text-gray-500">Searching...</div>}
        {!loading && listToShow.length === 0 && (
          <div className="p-4 text-gray-500">No users or conversations found</div>
        )}

        

        {Array.isArray(listToShow) && listToShow.length > 0 ? (
          listToShow.map((c) => (
          <div
            key={c.id || c.user_id}
            className="flex items-center border-b border-gray-200 py-3 cursor-pointer hover:bg-gray-50"
            onClick={async () => {
            let convoData = c;
            onSelectConversation(convoData);
          }}

          >
            <div className="bg-gray-200 p-2 rounded-full px-3 mr-3">
              <h1 className="font-semibold text-gray-500">
                {(c.other_username || c.username)?.[0]?.toUpperCase() || "U"}
              </h1>
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-gray-600">
                {c.other_username || c.username}
              </h3>
              <p className="text-xs text-gray-500">
                {c.last_message ? c.last_message : c.email ? c.email : "No messages yet"}
              </p>
            </div>
            {c.unread > 0 && (
              <div className="bg-red-500 text-white px-2 rounded-full text-xs">{c.unread}</div>
            )}
          </div>
        )) 
      ) : (
  !loading && <div className="p-4 text-gray-500">No users or conversations found</div>
)}
      </div>
    </div>
  );
};

export default HomePageUsers;
